#pragma once 
#include <string>
#include < iostream> 
using namespace std ;

class file
{
public: 
	string username , Password , Money;
	int Number ; 
	bool Exit ; 

	void name_val ();
	void NewFile (string username , string pasword,int number , string money );
	void chose_operation () ; 
	void Delete_account () ; 
	void deposit () ; 
	void whitherdaw () ;
	void view_account ();
	void vew_all_account () ;
	void file_size () ; 
	void chang_password () ; 
	bool Try_number (string number) ; 

};


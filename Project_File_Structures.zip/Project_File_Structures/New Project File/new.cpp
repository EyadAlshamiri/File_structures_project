#include <iostream > 
#include <fstream> 
#include <string> 
#include "file.h"
using namespace std ; 
int  main () 
{
	string enter ; 
	file f ;  

	f.Exit = true ; 
	
	try {
	while (f.Exit == true )
	{
		f.chose_operation() ; 
	}
	}
	catch (exception e ) 
	{}

	return 0 ; 
}